<?php
//Client Id of REST app
define("CLIENT_ID", "AZDxjDScFpQtjWTOUtWKbyN_bDt4OgqaF4eYXlewfBP4-8aqX3PiV8e1GWU6liB2CUXlkA59kJXE7M6R");

//ButtonSource Tracker Code
define("SBN_CODE","PP-DemoPortal-PPCredit-JSV4-php-REST");
?>